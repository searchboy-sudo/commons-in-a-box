<div id="infinity-cpanel-options" class="ui-helper-clearfix">
	<?php infinity_options_render_menu() ?>
	<div id="infinity-cpanel-options-content">
		<div id="infinity-cpanel-options-flash">
		</div>
		<form action="" method="POST">
			<!-- section and options markup is injected here via AJAX -->
		</form>
	</div>
</div>

<div class="entry__citation"><?php echo wp_kses_post( $data ); ?></div>

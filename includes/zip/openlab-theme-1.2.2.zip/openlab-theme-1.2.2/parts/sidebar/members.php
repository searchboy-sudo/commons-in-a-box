<div id="sidebar" class="sidebar col-sm-6 col-xs-24 type-members">
	<div class="sidebar-wrapper">
		<?php bp_get_template_part( 'members/single/sidebar' ); ?>
	</div>
</div>
